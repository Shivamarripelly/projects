# Online Voting Website
A online voting website.

## Roles:
* Admin
* Voter

## Functionality:
* Admin adds the data of candidate.
* Voters vote for candidate.

## Programming Environment:

### Front End:
HTML5, CSS3, JavaScript, jQuery v3.5.1, Bootstrap v4.5.0

### Back End:
PHP v7.2

### Database:
Maria DB
