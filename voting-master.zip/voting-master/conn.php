<?php

$con = mysqli_connect('localhost:3307','root','','voting');

$base_url = 'http://localhost/voting/';
?>